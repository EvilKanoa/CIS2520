var searchData=
[
  ['deletearrival',['deleteArrival',['../fourwaystop_8c.html#a0cb4d122e4772b38518027dbd1128479',1,'fourwaystop.c']]],
  ['deletedatafromlist',['deleteDataFromList',['../LinkedListAPI_8h.html#ae1a14b22705ddc68f907e6732f4d0843',1,'deleteDataFromList(List *list, void *toBeDeleted):&#160;linkedlist.c'],['../linkedlist_8c.html#ae1a14b22705ddc68f907e6732f4d0843',1,'deleteDataFromList(List *list, void *toBeDeleted):&#160;linkedlist.c']]],
  ['deletelist',['deleteList',['../LinkedListAPI_8h.html#abc18ab05ec8bd1b4ea085d5b30baf536',1,'deleteList(List *list):&#160;linkedlist.c'],['../linkedlist_8c.html#abc18ab05ec8bd1b4ea085d5b30baf536',1,'deleteList(List *list):&#160;linkedlist.c']]],
  ['dequeue',['dequeue',['../QueueAPI_8h.html#a0133c7e4da948f6a9368a0b0c4e2fbf9',1,'dequeue(Queue *queue):&#160;queue.c'],['../queue_8c.html#a0133c7e4da948f6a9368a0b0c4e2fbf9',1,'dequeue(Queue *queue):&#160;queue.c']]],
  ['done',['done',['../KTest_8h.html#a38b15ec1ac277534bf080fe179eaa077',1,'done(TestingContext *context):&#160;KTest.c'],['../KTest_8c.html#a38b15ec1ac277534bf080fe179eaa077',1,'done(TestingContext *context):&#160;KTest.c']]],
  ['duelprint',['duelPrint',['../fourwaystop_8c.html#a249221e746c9e49beb30671cd18ac0b4',1,'fourwaystop.c']]]
];

var searchData=
[
  ['arrivaldata',['arrivalData',['../structarrivalData.html',1,'']]]
];

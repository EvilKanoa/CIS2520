var searchData=
[
  ['newcontext',['newContext',['../KTest_8h.html#a9e7ece7dbad326fa1f4d393e93379e3a',1,'newContext(char *programName):&#160;KTest.c'],['../KTest_8c.html#a9e7ece7dbad326fa1f4d393e93379e3a',1,'newContext(char *programName):&#160;KTest.c']]],
  ['node',['Node',['../LinkedListAPI_8h.html#a2b677d2e8ffc156e6b24a55e7338ecad',1,'LinkedListAPI.h']]]
];

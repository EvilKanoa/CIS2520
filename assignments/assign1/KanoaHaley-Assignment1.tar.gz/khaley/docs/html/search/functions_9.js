var searchData=
[
  ['queuecreate',['queueCreate',['../QueueAPI_8h.html#aa03a25c923c176a18b4d4bb8b76ffee7',1,'queueCreate(void(*printFunction)(void *toBePrinted), void(*deleteFunction)(void *toBeDeleted)):&#160;queue.c'],['../queue_8c.html#aa03a25c923c176a18b4d4bb8b76ffee7',1,'queueCreate(void(*printFunction)(void *toBePrinted), void(*deleteFunction)(void *toBeDeleted)):&#160;queue.c']]],
  ['queuedestroy',['queueDestroy',['../QueueAPI_8h.html#aa2081e9299f0d0aceb51fc8d32570a46',1,'queueDestroy(Queue *queue):&#160;queue.c'],['../queue_8c.html#aa2081e9299f0d0aceb51fc8d32570a46',1,'queueDestroy(Queue *queue):&#160;queue.c']]],
  ['queuefromlist',['queueFromList',['../QueueAPI_8h.html#a74d43f02d0b7cbd4a0721098783ac11a',1,'queueFromList(List *data):&#160;queue.c'],['../queue_8c.html#a74d43f02d0b7cbd4a0721098783ac11a',1,'queueFromList(List *data):&#160;queue.c']]],
  ['queuelength',['queueLength',['../QueueAPI_8h.html#a69bb3f28dbcaa51e91f03a89186a0a4d',1,'queueLength(Queue *queue):&#160;queue.c'],['../queue_8c.html#a69bb3f28dbcaa51e91f03a89186a0a4d',1,'queueLength(Queue *queue):&#160;queue.c']]],
  ['queuepeak',['queuePeak',['../QueueAPI_8h.html#a4a9b65aa09e62fafabb57df322d803a4',1,'queuePeak(Queue *queue):&#160;queue.c'],['../queue_8c.html#a4a9b65aa09e62fafabb57df322d803a4',1,'queuePeak(Queue *queue):&#160;queue.c']]]
];

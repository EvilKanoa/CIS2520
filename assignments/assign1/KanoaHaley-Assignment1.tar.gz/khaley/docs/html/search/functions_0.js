var searchData=
[
  ['begin',['begin',['../KTest_8h.html#a7b11ac9bf6032ecad8566347518b4a4f',1,'begin(TestingContext *context):&#160;KTest.c'],['../KTest_8c.html#a7b11ac9bf6032ecad8566347518b4a4f',1,'begin(TestingContext *context):&#160;KTest.c']]]
];
